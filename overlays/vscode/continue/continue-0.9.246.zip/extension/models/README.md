all-MiniLM-L6-v2 is the sentence transformers model used with transformers.js to locally generate codebase embeddings.

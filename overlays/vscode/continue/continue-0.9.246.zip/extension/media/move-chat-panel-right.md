# Move Chat to the right sidebar

### This will prevent the Chat panel from covering your file explorer

![Move Continue to right sidebar](./move-to-right-sidebar.gif)
